package com.grouper;

import org.testng.annotations.*;

public class Grouper {

    @BeforeClass
    public void aSetBrowserTest() {
        System.out.println("Setting the browser ...");
        System.out.println("The browser has been set.");
    }


    @BeforeClass
    public void openBrowserTest() {
        System.out.println("Opening the browser ...");
        System.out.println("Browser open successfully.");
    }


    @BeforeMethod
    public void openAppTest() {
        System.out.println("Opening the application ...");
        System.out.println("Application open successfully.");
    }


    @BeforeMethod
    public void signInTest() {
        System.out.println("User is logged in application.");

    }


    @Test(priority = -1, description = "this is a test for the searching functionality.")
    public void searchingItemTest() {
        System.out.println("Searching for item ...");
        System.out.println("Results for the search are displayed.");
    }


    @Test(priority = 1, description = "Adding item to chart functionality test.")
    public void addItemTest() {
        System.out.println("Adding item to cart ...");
        System.out.println("Item successfully added to cart.");
    }


    @AfterMethod
    public void aSignOutTest() {
        System.out.println("User is logged out.");

    }
    

    @AfterMethod
    public void closeAppTest() {
        System.out.println("Closing the application ...");
        System.out.println("Application closed successfully.");
    }


    @AfterClass
    public void closeBrowserTest() {
        System.out.println("Browser closed.");
    }
}
