import com.milkshake.Milkshake;
import org.testng.Assert;
import org.testng.annotations.*;

public class MilkshakeTest {


    @Test
    public void testIfChocolateMIlkshakeWithAlmondsHaveTheSamePriceAsChocolateMIlkshakeWithNutsTest(){
        Milkshake m1 = new Milkshake("Almonds");
        Milkshake m2 = new Milkshake("Nuts");
        Assert.assertEquals(m1.milkShakePrice(), m2.milkShakePrice());
    }


    @Test (priority = 1)
    public void testIfChocolateMIlkshakeWithAlmondsHaveDifferentPriceFromChocolateMIlkshakeWithCaramelTest(){
        Milkshake m1 = new Milkshake("Almonds");
        Milkshake m2 = new Milkshake("Caramel");
        Assert.assertNotEquals(m1.milkShakePrice(), m2.milkShakePrice());
    }


    @Test (priority = 2)
    public void testIfChocolateMIlkshakeWithCaramelHasTheValuesTest(){
        Milkshake m = new Milkshake("Caramel");
        Assert.assertNotEquals(m.getMILKSHAKE(),0);
        Assert.assertNotEquals(m.getCARAMEL(),0);
    }


    @Test (priority = 3)
    public void testIfChocolateMIlkshakeWithCaramelIsNotEmptyTest(){
        Milkshake m = new Milkshake("Caramel");
        Assert.assertNotNull(m);
    }


    @Test (priority = 4)
    public void testIfChocolateMIlkshakeWithAlmondsHaveTheSamePriceAsChocolateMIlkshakeWithPistachiosTest(){
        Milkshake m1 = new Milkshake("Almonds");
        Milkshake m2 = new Milkshake("Pistachios");
        Assert.assertEquals(m1.milkShakePrice(), m2.milkShakePrice());
    }


}
