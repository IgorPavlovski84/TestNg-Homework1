import com.milkshake.Milkshake;
import org.testng.Assert;
import org.testng.annotations.*;

public class MilkshakeTest {

    Milkshake m1 = new Milkshake("Almonds");
    Milkshake m2 = new Milkshake("Nuts");
    Milkshake m3 = new Milkshake("Caramel");
    Milkshake m4 = new Milkshake("Pistachios");

    @Test(description = "Testing if price for milkshake with nuts is the same as milkshake with almonds.")
    public void testIfChocolateMIlkshakeWithAlmondsHaveTheSamePriceAsChocolateMIlkshakeWithNutsTest(){
        Assert.assertEquals(m1.milkShakePrice(), m2.milkShakePrice());
    }


    @Test (priority = 1, description = "Testing that the price for milkshake with almonds is different from" +
            " the price of milkshake with caramel ")
    public void testIfChocolateMIlkshakeWithAlmondsHaveDifferentPriceFromChocolateMIlkshakeWithCaramelTest(){
        Assert.assertNotEquals(m1.milkShakePrice(), m2.milkShakePrice());
    }


    @Test (priority = 2, description = "Testing that milkshake with caramel has values." )
    public void testIfChocolateMIlkshakeWithCaramelHasTheValuesTest(){
        Assert.assertNotEquals(m3.getMilkshake(),0);
        Assert.assertNotEquals(m3.getCaramel(),0);
    }


    @Test (priority = 3, description = "Testing if milkshake with caramel is not empty.")
    public void testIfChocolateMIlkshakeWithCaramelIsNotEmptyTest(){
        Assert.assertNotNull(m3);
    }


    @Test (priority = 4, description = "Testing if price for milkshake with almonds is the same as " +
            "milkshake with pistachios.")
    public void testIfChocolateMIlkshakeWithAlmondsHaveTheSamePriceAsChocolateMIlkshakeWithPistachiosTest(){
        Assert.assertEquals(m1.milkShakePrice(), m4.milkShakePrice());
    }


}
