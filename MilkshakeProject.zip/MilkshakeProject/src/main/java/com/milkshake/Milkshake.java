package com.milkshake;

public class Milkshake {

    final int MILKSHAKE = 15;
    final int ALMONDS = 5;
    final int CARAMEL = 6;
    final int PISTACHIOS = 5;
    final int NUTS = 3;
    String flavor;


    public Milkshake(String flavor) {
        this.flavor = flavor;

    }

    public int getMILKSHAKE() {
        return MILKSHAKE;
    }

    public int getALMONDS() {
        return ALMONDS;
    }

    public int getCARAMEL() {
        return CARAMEL;
    }

    public int getPISTACHIOS() {
        return PISTACHIOS;
    }

    public int getNUTS() {
        return NUTS;
    }


    public int milkShakePrice() {
        if (flavor.equals("Almonds")) {
            return MILKSHAKE + ALMONDS;
        } else if (flavor.equals("Caramel")) {
            return MILKSHAKE + CARAMEL;
        } else if (flavor.equals("Pistachios")) {
            return MILKSHAKE + PISTACHIOS;
        } else if (flavor.equals("Nuts")) {
            return MILKSHAKE + NUTS;
        } else {
            return 0;
        }

    }

}