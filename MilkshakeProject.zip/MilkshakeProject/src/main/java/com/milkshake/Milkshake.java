package com.milkshake;

public class Milkshake {

    final int milkshake = 15;
    final int almonds = 5;
    final int caramel = 6;
    final int pistachios = 5;
    final int nuts = 3;
    String flavor;


    public Milkshake(String chosenFlavor) {
        this.flavor = chosenFlavor;

    }

    public int getMilkshake() {
        return this.milkshake;
    }

    public int getAlmonds() {
        return this.almonds;
    }

    public int getCaramel() {
        return this.caramel;
    }

    public int getPistachios() {
        return this.pistachios;
    }

    public int getNuts() {
        return this.nuts;
    }


    public int milkShakePrice() {
        if (flavor.equals("Almonds")) {
            return this.milkshake + this.almonds;
        } else if (flavor.equals("Caramel")) {
            return this.milkshake + this.caramel;
        } else if (flavor.equals("Pistachios")) {
            return this.milkshake + this.pistachios;
        } else if (flavor.equals("Nuts")) {
            return this.milkshake + this.nuts;
        } else {
            return 0;
        }

    }

}